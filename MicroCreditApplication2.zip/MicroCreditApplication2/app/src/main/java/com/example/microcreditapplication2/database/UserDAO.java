package com.example.microcreditapplication2.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface UserDAO {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertUser(User user);

    @Query("SELECT * FROM user where username=:username AND password=:password")
    User checkUser(String username,String password);

    @Query("UPDATE user SET money =:money WHERE username =:username")
    void updateData(int money,String username);

    @Query("UPDATE user SET money = money - :money WHERE username=:username")
    void subtractMoneyByUsername(String username,int money);

    @Query("SELECT * FROM user WHERE username = :username")
    User getUserByUsername(String username);

    @Query("DELETE FROM user")
    void deleteAllUsers();

    @Query("UPDATE user SET money = money + :money WHERE username=:username")
    void addMoneyByUsername(String username,int money);

    @Query("SELECT * FROM user WHERE username=:username")
    User ifUserIsExist(String username);

}
