package com.example.microcreditapplication2.ui.sendMoney;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.microcreditapplication2.R;
import com.example.microcreditapplication2.database.LoggedUser;
import com.example.microcreditapplication2.database.Transaction;
import com.example.microcreditapplication2.database.User;
import com.example.microcreditapplication2.database.UserDatabase;
import com.example.microcreditapplication2.helper.GeneralData;
import com.example.microcreditapplication2.ui.home.HomeFragment;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SendMoneyFragment extends Fragment {

    private EditText et_receiverUsername;
    private EditText et_money;
    private Button btn_send;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_send_money, container, false);

        et_receiverUsername = view.findViewById(R.id.receiverUsername);
        et_money = view.findViewById(R.id.howMuch);
        btn_send = view.findViewById(R.id.sendMoneyButton);

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = GeneralData.getLoggedUser().getUsername();
                UserDatabase database = UserDatabase.getInstance(getContext());
                User ifExist = database.userDAO().ifUserIsExist(et_receiverUsername.getText().toString());

                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                Date date = new Date();
                String curDate = formatter.format(date);

                String sender = et_receiverUsername.getText().toString();
                int money = Integer.parseInt(et_money.getText().toString());

                if(ifExist!=null){
                    database.userDAO().addMoneyByUsername(sender,money);
                    database.userDAO().subtractMoneyByUsername(username,money);
                    User user = database.userDAO().getUserByUsername(username);
                    GeneralData.getLoggedUser().setWallet(GeneralData.getLoggedUser().getWallet()-money);
                    database.transactionDAO().addTransaction(new Transaction(username,sender,money,curDate));
                    Toast.makeText(getContext(),"Успешно переведено " + money + "$",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getContext(), "Нет такого пользователя", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }

}