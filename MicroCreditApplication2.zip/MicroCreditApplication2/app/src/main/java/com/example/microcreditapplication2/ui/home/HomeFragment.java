package com.example.microcreditapplication2.ui.home;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.microcreditapplication2.R;
import com.example.microcreditapplication2.adapter.CurrencyListAdapter;
import com.example.microcreditapplication2.adapter.TransactionListAdapter;
import com.example.microcreditapplication2.database.Currency;
import com.example.microcreditapplication2.database.Transaction;
import com.example.microcreditapplication2.database.UserDatabase;
import com.example.microcreditapplication2.databinding.FragmentHomeBinding;
import com.example.microcreditapplication2.helper.GeneralData;
import com.example.microcreditapplication2.ui.exchangeCurrency.ExchangeCurrencyFragment;
import com.example.microcreditapplication2.ui.sendMoney.SendMoneyFragment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class HomeFragment extends Fragment implements View.OnClickListener {

    private TextView tv_username;
    private TextView tv_userMoney;
    private TransactionListAdapter transactionListAdapter;
    private CurrencyListAdapter currencyListAdapter;
    private List<Transaction> transactions;
    private List<Currency> currencies;
    private ImageButton ib_sendButton,ib_exchangeButton;
    private String username;


    private RecyclerView rv_transaction;
    private RecyclerView rv_currency;

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        username = GeneralData.getLoggedUser().getUsername();
        String fullName = GeneralData.getLoggedUser().getFullname();

        tv_username = binding.homeUsername;
        tv_username.setText(fullName);

        tv_userMoney = binding.homeWallet;



        int money = GeneralData.getLoggedUser().getWallet();

        tv_userMoney.setText("$"+money);

        ib_sendButton = binding.homeSend;
        ib_exchangeButton = binding.homeExchange;

        rv_transaction = binding.recyclerViewTransaction;
        rv_transaction.setLayoutManager(new LinearLayoutManager(this.getContext()));
        transactionListAdapter = new TransactionListAdapter(this.getContext());
        rv_transaction.setAdapter(transactionListAdapter);

        rv_currency = binding.recyclerViewCurrency;
        rv_currency.setLayoutManager(new LinearLayoutManager(this.getContext()));
        currencyListAdapter = new CurrencyListAdapter(this.getContext());
        rv_currency.setAdapter(currencyListAdapter);

        loadAllTransactionsAndCurrency();

        ib_exchangeButton.setOnClickListener(this);
        ib_sendButton.setOnClickListener(this);
        return root;
    }

    public void loadAllTransactionsAndCurrency(){

        UserDatabase database = UserDatabase.getInstance(requireContext());
        transactions = database.transactionDAO().getAllTransactionsByUsername(username);
        transactionListAdapter.setTransactions(transactions);

        currencies = database.transactionDAO().getAllCurrencyByUsername(username);
        currencyListAdapter.setCurrencies(currencies);

    }

    @Override
    public void onClick(View view) {
        Fragment fragment = null;
        switch (view.getId()) {
            case R.id.homeSend:
                fragment = new SendMoneyFragment();
                replaceFragment(fragment);
                break;

            case R.id.homeExchange:
                fragment = new ExchangeCurrencyFragment();
                replaceFragment(fragment);
                break;
        }
    }

    public void replaceFragment(Fragment someFragment) {
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.nav_host_fragment_activity_main, someFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

}