package com.example.microcreditapplication2.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface TransactionDAO {

    @Query("SELECT * FROM `transaction` WHERE sender = :username")
    List<Transaction> getAllTransactionsByUsername(String username);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addTransaction(Transaction transaction);

    @Query("DELETE FROM `transaction`")
    void deleteAllTransactions();

    @Query("SELECT * FROM currency WHERE receiver = :username")
    List<Currency> getAllCurrencyByUsername(String username);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addCurrency(Currency currency);

}
