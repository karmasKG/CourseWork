package com.example.microcreditapplication2.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "transaction")
public class Transaction {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "sender")
    private String senderUsername;

    @ColumnInfo(name = "receiver")
    private String receiverUsername;

    @ColumnInfo(name = "money")
    private int money;

    @ColumnInfo(name = "sentAt")
    private String sentAt;

    public Transaction() {
    }

    public Transaction(String senderUsername, String receiverUsername,int money,String sentAt) {
        this.senderUsername = senderUsername;
        this.receiverUsername = receiverUsername;
        this.money = money;
        this.sentAt = sentAt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public String getSenderUsername() {
        return senderUsername;
    }

    public void setSenderUsername(String senderUsername) {
        this.senderUsername = senderUsername;
    }

    public String getReceiverUsername() {
        return receiverUsername;
    }

    public void setReceiverUsername(String receiverUsername) {
        this.receiverUsername = receiverUsername;
    }

    public String getSentAt() {
        return sentAt;
    }

    public void setSentAt(String sentAt) {
        this.sentAt = sentAt;
    }
}
