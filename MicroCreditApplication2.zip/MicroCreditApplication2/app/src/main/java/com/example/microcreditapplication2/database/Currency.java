package com.example.microcreditapplication2.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "currency")
public class Currency {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "receiver")
    private String receiverUsername;

    @ColumnInfo(name = "fromCur")
    private String fromCurrency;

    @ColumnInfo(name = "toCur")
    private String toCurrency;

    @ColumnInfo(name = "amount")
    private int amount;

    public Currency() {
    }

    public Currency(String receiverUsername, String fromCurrency, String toCurrency,int amount) {
        this.receiverUsername = receiverUsername;
        this.fromCurrency = fromCurrency;
        this.toCurrency = toCurrency;
        this.amount = amount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getReceiverUsername() {
        return receiverUsername;
    }

    public void setReceiverUsername(String receiverUsername) {
        this.receiverUsername = receiverUsername;
    }

    public String getFromCurrency() {
        return fromCurrency;
    }

    public void setFromCurrency(String fromCurrency) {
        this.fromCurrency = fromCurrency;
    }

    public String getToCurrency() {
        return toCurrency;
    }

    public void setToCurrency(String toCurrency) {
        this.toCurrency = toCurrency;
    }
}
