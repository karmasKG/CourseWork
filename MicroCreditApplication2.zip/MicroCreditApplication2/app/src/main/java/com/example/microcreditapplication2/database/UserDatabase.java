package com.example.microcreditapplication2.database;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.microcreditapplication2.adapter.CurrencyListAdapter;

@Database(entities = {User.class,Transaction.class, Currency.class},version = 6,exportSchema = false)
public abstract class UserDatabase extends RoomDatabase {

    //Создание экземпляра базы данных
    private static UserDatabase userDatabase;

    //Назначить имя для базы данных
    private static String databaseName = "bank_system";

    public synchronized static UserDatabase getInstance(Context context)
    {
        //Проверка
        if(userDatabase == null)
        {
            //Если репозиторий null то инициализируем базу данных
            userDatabase = Room.databaseBuilder(context.getApplicationContext(),
                    UserDatabase.class,databaseName)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return userDatabase;
    }

    //Создание экземпляра UserDAO
    public abstract UserDAO userDAO();

    //Создание экземпляра TransactionDAO
    public abstract TransactionDAO transactionDAO();


}
