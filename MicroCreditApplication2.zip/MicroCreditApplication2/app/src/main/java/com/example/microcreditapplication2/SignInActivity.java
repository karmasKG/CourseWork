package com.example.microcreditapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.microcreditapplication2.database.LoggedUser;
import com.example.microcreditapplication2.database.User;
import com.example.microcreditapplication2.database.UserDatabase;
import com.example.microcreditapplication2.helper.GeneralData;
import com.example.microcreditapplication2.registration.RegistrationActivity;
import com.example.microcreditapplication2.ui.home.HomeFragment;

public class SignInActivity extends AppCompatActivity {

    private EditText et_username;
    private EditText et_password;
    private TextView tv_wrong;
    private LoggedUser loggedUser;
    private Button registration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        UserDatabase database = UserDatabase.getInstance(this.getApplicationContext());
        database.userDAO().insertUser(new User("adilAbdr","adil111","Adil Abdr",2800));
        database.userDAO().insertUser(new User("egor228","qwerty123","Egor Viner",1800));

        init();

        registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignInActivity.this, RegistrationActivity.class);
                startActivity(intent);
            }
        });
    }

    void init(){
        et_password = findViewById(R.id.password);
        et_username = findViewById(R.id.username);
        tv_wrong = findViewById(R.id.wrong);
        registration = findViewById(R.id.registrationSignIn);
    }

    public void checkData(View view){
        UserDatabase database = UserDatabase.getInstance(this.getApplicationContext());

        String username = et_username.getText().toString();
        String password = et_password.getText().toString();

        User user = database.userDAO().checkUser(username,password);

        if(user!=null){
            loggedUser = new LoggedUser();
            loggedUser.setFullname(user.getFullname());
            loggedUser.setUsername(user.getUsername());
            loggedUser.setPassword(user.getPassword());
            loggedUser.setWallet(user.getWallet());
            loggedUser.setId(user.getId());
            GeneralData.setLoggedUser(loggedUser);
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else{
            tv_wrong.setVisibility(View.VISIBLE);
        }
    }

}