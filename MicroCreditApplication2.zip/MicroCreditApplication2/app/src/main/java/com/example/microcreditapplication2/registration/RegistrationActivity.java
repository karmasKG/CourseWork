package com.example.microcreditapplication2.registration;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import com.example.microcreditapplication2.R;
import com.example.microcreditapplication2.database.User;
import com.example.microcreditapplication2.database.UserDatabase;

public class RegistrationActivity extends AppCompatActivity {

    private EditText et_password;
    private EditText et_login;
    private EditText et_fullname;
    private UserDatabase database;
    private TextView tv_wrong;
    private Button registration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        init();

    }

    public void registerUser(View view){
        database = UserDatabase.getInstance(this);

        String username = et_login.getText().toString();
        String password = et_password.getText().toString();
        String fullname = et_fullname.getText().toString();
        int money = 10;

        if(username.length()==0 || password.length() == 0 || fullname.length() == 0 ||username.length()<6 || password.length()<6)
        {
            Toast.makeText(this, "Пароль и логин должны состоять от 7 символов!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            database.userDAO().insertUser(new User(username,password,fullname,money));
            finish();
            Toast.makeText(this, "Вы успешно зарегистрировались!", Toast.LENGTH_SHORT).show();
        }
    }

    void init(){
        et_password = findViewById(R.id.passwordReg);
        et_fullname = findViewById(R.id.fullNameReg);
        et_login = findViewById(R.id.usernameReg);
        tv_wrong = findViewById(R.id.wrongReg);
        registration = findViewById(R.id.registrationButton);
    }

}