package com.example.microcreditapplication2.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.microcreditapplication2.R;
import com.example.microcreditapplication2.database.Transaction;

import java.util.List;

public class TransactionListAdapter extends RecyclerView.Adapter<TransactionListAdapter.MyViewHolder> {

    private Context context;
    private List<Transaction> transactions;

    public TransactionListAdapter(Context context){
        this.context = context;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_transaction,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.tv_dateTransaction.setText(this.transactions.get(position).getSentAt());
        holder.tv_receiver.setText(this.transactions.get(position).getReceiverUsername());
        holder.tv_money.setText(String.valueOf(this.transactions.get(position).getMoney()));
    }


    @Override
    public int getItemCount() {
        return transactions.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tv_dateTransaction;
        TextView tv_money;
        TextView tv_receiver;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_dateTransaction = itemView.findViewById(R.id.dateTransaction);
            tv_money = itemView.findViewById(R.id.money);
            tv_receiver = itemView.findViewById(R.id.sendWho);
        }
    }
}
