package com.example.microcreditapplication2.helper;


import com.example.microcreditapplication2.database.LoggedUser;

public class GeneralData {

    private static LoggedUser loggedUser;

    public static void setLoggedUser(LoggedUser user){
        loggedUser = user;
    }

    public static LoggedUser getLoggedUser(){
        return loggedUser;
    }


}
