package com.example.microcreditapplication2.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.microcreditapplication2.R;
import com.example.microcreditapplication2.adapter.TransactionListAdapter;
import com.example.microcreditapplication2.database.Transaction;
import com.example.microcreditapplication2.database.User;
import com.example.microcreditapplication2.database.UserDatabase;
import com.example.microcreditapplication2.databinding.FragmentDashboardBinding;
import com.example.microcreditapplication2.helper.GeneralData;
import com.example.microcreditapplication2.ui.addMoney.AddMoneyFragment;

import java.util.List;

public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;
    private TextView tv_username;
    private TextView tv_password;
    private TextView tv_wallet;

    private RecyclerView rv_transaction;
    private Button btn_rechargeBalance;
    private List<Transaction> transactions;
    private TransactionListAdapter adapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        UserDatabase database = UserDatabase.getInstance(getContext());

        tv_username = binding.usernameProfile;
        tv_password = binding.passwordProfile;
        tv_wallet = binding.moneyProfile;
        rv_transaction = binding.recyclerViewProfile;
        btn_rechargeBalance = binding.btnAddMoney;

        String username = GeneralData.getLoggedUser().getUsername();

        tv_wallet.setText(String.valueOf(GeneralData.getLoggedUser().getWallet()));
        tv_username.setText(GeneralData.getLoggedUser().getUsername());
        tv_password.setText(GeneralData.getLoggedUser().getPassword());

        transactions = database.transactionDAO().getAllTransactionsByUsername(username);
        rv_transaction.setLayoutManager(new LinearLayoutManager(this.getContext()));
        adapter = new TransactionListAdapter(getContext());
        adapter.setTransactions(transactions);
        rv_transaction.setAdapter(adapter);

        btn_rechargeBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity) view.getContext();
                Fragment fragment = new AddMoneyFragment();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment_activity_main, fragment).addToBackStack(null).commit();
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}