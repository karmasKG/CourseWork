package com.example.microcreditapplication2.ui.addMoney;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.microcreditapplication2.R;
import com.example.microcreditapplication2.database.LoggedUser;
import com.example.microcreditapplication2.database.User;
import com.example.microcreditapplication2.database.UserDatabase;
import com.example.microcreditapplication2.helper.GeneralData;

public class AddMoneyFragment extends Fragment {

    private EditText et_cardNum;
    private EditText et_expDate1;
    private EditText et_expDate2;
    private EditText et_cvv;
    private EditText et_money;
    private Button btn_recharge;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_money,container,false);

        UserDatabase database = UserDatabase.getInstance(getContext());

        et_cardNum = view.findViewById(R.id.cardNumber);
        et_expDate1 = view.findViewById(R.id.expDateFirst);
        et_expDate2 = view.findViewById(R.id.expDateSecond);
        et_cvv = view.findViewById(R.id.cvvNum);
        et_money = view.findViewById(R.id.moneyRecharge);
        btn_recharge = view.findViewById(R.id.rechargeButton);


        String username = GeneralData.getLoggedUser().getUsername();
        btn_recharge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cardNum = et_cardNum.getText().toString();
                String expDate1 = et_expDate1.getText().toString();
                String expDate2 = et_expDate2.getText().toString();
                String cvv = et_cvv.getText().toString();
                String money = et_money.getText().toString();
                System.out.println(cardNum.length()+ " " + expDate1.length() + " " + expDate2.length() + " " + cvv.length());
                if(cardNum.length()!=16 || expDate1.length()!=2 || expDate2.length()!=2 || cvv.length()!=3){
                    Toast.makeText(getContext(), "Заполните все поля корректно!", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getContext(), "Ваш баланс успешно пополнен на сумму $" + money, Toast.LENGTH_SHORT).show();
                    User user = database.userDAO().getUserByUsername(username);
                    LoggedUser loggedUser = new LoggedUser();
                    loggedUser.setId(GeneralData.getLoggedUser().getId());
                    loggedUser.setFullname(GeneralData.getLoggedUser().getFullname());
                    loggedUser.setUsername(GeneralData.getLoggedUser().getUsername());
                    loggedUser.setPassword(GeneralData.getLoggedUser().getPassword());
                    loggedUser.setWallet(GeneralData.getLoggedUser().getWallet()+Integer.parseInt(money));
                    loggedUser.setWallet(user.getWallet()+Integer.parseInt(money));
                    GeneralData.setLoggedUser(loggedUser);
                    database.userDAO().addMoneyByUsername(username,Integer.parseInt(money));
                }
            }
        });

        return view;
    }
}