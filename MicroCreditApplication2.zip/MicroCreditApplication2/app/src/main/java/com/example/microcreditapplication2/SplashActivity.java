package com.example.microcreditapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import com.example.microcreditapplication2.database.Transaction;
import com.example.microcreditapplication2.database.UserDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SplashActivity extends AppCompatActivity {

    private Animation animText1, animText2;
    private TextView tv_text1;
    private Button btn_in;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        tv_text1 = findViewById(R.id.text1);
        btn_in = findViewById(R.id.splashButton);

        animText1 = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_right);
        animText2 = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_right);

        tv_text1.startAnimation(animText1);

        btn_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),SignInActivity.class);
                startActivity(intent);
            }
        });

    }



}