package com.example.microcreditapplication2.ui.exchangeCurrency;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.microcreditapplication2.R;
import com.example.microcreditapplication2.database.Currency;
import com.example.microcreditapplication2.database.LoggedUser;
import com.example.microcreditapplication2.database.User;
import com.example.microcreditapplication2.database.UserDatabase;
import com.example.microcreditapplication2.database.UserDatabase_Impl;
import com.example.microcreditapplication2.helper.GeneralData;

public class ExchangeCurrencyFragment extends Fragment {

    private EditText et_fromCur;
    private EditText et_toCur;
    private EditText et_amount;
    private Button btn_exchange;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_exchange_currency,container,false);
        UserDatabase database = UserDatabase.getInstance(getContext());
        User user = database.userDAO().checkUser(
                GeneralData.getLoggedUser().getUsername(),
                GeneralData.getLoggedUser().getPassword());

        et_toCur = view.findViewById(R.id.toCurrencyFragment);
        et_amount = (EditText) view.findViewById(R.id.amountFragment);
        et_fromCur = view.findViewById(R.id.fromCurrencyFragment);
        String username = GeneralData.getLoggedUser().getUsername();


        btn_exchange = view.findViewById(R.id.exchangeButton);

        btn_exchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    int money = Integer.parseInt(et_amount.getText().toString());
                    database.transactionDAO().addCurrency(new Currency(
                            username,
                            et_fromCur.getText().toString(),
                            et_toCur.getText().toString(),
                            money));
                    database.userDAO().subtractMoneyByUsername(username, money);

                    user.setWallet(GeneralData.getLoggedUser().getWallet()-money);

//                    LoggedUser loggedUser = new LoggedUser();
//                    loggedUser.setId(GeneralData.getLoggedUser().getId());
//                    loggedUser.setFullname(GeneralData.getLoggedUser().getFullname());
//                    loggedUser.setUsername(GeneralData.getLoggedUser().getUsername());
//                    loggedUser.setPassword(GeneralData.getLoggedUser().getPassword());
//                    loggedUser.setWallet(GeneralData.getLoggedUser().getWallet()-money);
//                    GeneralData.setLoggedUser(loggedUser);

                }catch (NumberFormatException e){
                    e.printStackTrace();
                }
            }
        });

        return view;
    }
}