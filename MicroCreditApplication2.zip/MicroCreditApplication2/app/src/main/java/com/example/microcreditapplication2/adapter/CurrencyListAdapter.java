package com.example.microcreditapplication2.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.microcreditapplication2.R;
import com.example.microcreditapplication2.database.Currency;

import java.util.List;

public class CurrencyListAdapter extends RecyclerView.Adapter<CurrencyListAdapter.MyViewHolder> {

    private Context context;
    private List<Currency> currencies;

    public CurrencyListAdapter(Context context) {
        this.context = context;
        notifyDataSetChanged();
    }

    public void setCurrencies(List<Currency> currencies) {
        this.currencies = currencies;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_currency,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.tv_toCur.setText(currencies.get(position).getToCurrency());
        holder.tv_fromCur.setText(currencies.get(position).getFromCurrency());
        holder.tv_amount.setText(String.valueOf(currencies.get(position).getAmount()));
    }

    @Override
    public int getItemCount() {
        return currencies.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tv_fromCur;
        TextView tv_toCur;
        TextView tv_amount;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_amount = itemView.findViewById(R.id.amount);
            tv_fromCur = itemView.findViewById(R.id.fromCurrency);
            tv_toCur = itemView.findViewById(R.id.toCurrency);
        }
    }
}
